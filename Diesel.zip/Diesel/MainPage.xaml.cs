﻿using Diesel.Models;
using Newtonsoft.Json;
using System;
using Windows.Storage;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace Diesel
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public static MainPage mainPage { get; private set; }


        public string filenameBil = "Bil.txt";
        public string filenameTank = "Tankninger.txt";


        public MainPage()
        {
            this.InitializeComponent();
            mainPage = this;
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            LoadBil();

            OpretBilFlyoutButton.Visibility = Visibility.Collapsed;
            BilMarkeFlyout.IsEnabled = false;
            BilModelFlyout.IsEnabled = false;
            KmTaellerFlyout.IsEnabled = false;
            RedigerFlyoutButton.Visibility = Visibility.Visible;


            // set the initial SelectedItem
            foreach (NavigationViewItemBase item in Navigation.MenuItems)
            {
                if (item is NavigationViewItem && item.Tag.ToString() == "TankningsPage")
                {
                    Navigation.SelectedItem = item;
                    break;
                }
            }
            Frame.Navigate(typeof(Pages.TankningsPage));
        }


        private void Navigation_SelectionChanged(NavigationView sender, NavigationViewSelectionChangedEventArgs args)
        {
            //if(args.IsSettingsSelected)
            //{
            //    Frame.Navigate(typeof(Pages.SettingsPage));
            //}
            //else
            //{
                NavigationViewItem item = args.SelectedItem as NavigationViewItem;

                switch (item.Tag.ToString())
                {
                    case "TankningsPage":
                        Frame.Navigate(typeof(Pages.TankningsPage));
                        break;

                    case "DiversePage":
                        Frame.Navigate(typeof(Pages.DiversePage));
                        break;

                    case "OverAllPage":
                        Frame.Navigate(typeof(Pages.OverAllPage));
                        break;
                    }

            //}
        }

        private async void OpretBilFlyoutButton_Click(object sender, RoutedEventArgs e)
        {
            if (BilMarkeFlyout.Text == "" || BilModelFlyout.Text == "" || KmTaellerFlyout.Text == "")
            {
                MessageDialog messageOne = new MessageDialog("Data er ikke korrekt indtastet");
                messageOne.Options = MessageDialogOptions.None;
                messageOne.Commands.Add(new UICommand("Ok"));
                await messageOne.ShowAsync();
            }
            else
            {
                Bil bilData = new Bil();
                bilData.BilMarke = BilMarkeFlyout.Text;
                bilData.BilModel = BilModelFlyout.Text;
                bilData.KmTaller = KmTaellerFlyout.Text;

                string finalBilData = JsonConvert.SerializeObject(bilData);

                StorageFolder localFolder = Windows.Storage.ApplicationData.Current.LocalFolder;
                StorageFile fileBil = await localFolder.CreateFileAsync(filenameBil, CreationCollisionOption.ReplaceExisting);
                await FileIO.WriteTextAsync(fileBil, finalBilData);

                OpretBilFlyoutButton.Visibility = Visibility.Collapsed;
                BilMarkeFlyout.IsEnabled = false;
                BilModelFlyout.IsEnabled = false;
                KmTaellerFlyout.IsEnabled = false;
                RedigerFlyoutButton.Visibility = Visibility.Visible;

                MessageDialog messageTwo = new MessageDialog("Bilen er gemt");
                messageTwo.Options = MessageDialogOptions.None;
                messageTwo.Commands.Add(new UICommand("Ok"));
                await messageTwo.ShowAsync();
                LoadBil();
            }
        }

        public async void LoadBil()
        {
            try
            {
                StorageFolder localFolder = Windows.Storage.ApplicationData.Current.LocalFolder;
                StorageFile fileBil = await localFolder.CreateFileAsync(filenameBil, CreationCollisionOption.OpenIfExists);
                string finalData = await FileIO.ReadTextAsync(fileBil);

                Bil bilData = JsonConvert.DeserializeObject<Bil>(finalData);

                BilMarkeFlyout.Text = bilData.BilMarke;
                BilModelFlyout.Text = bilData.BilModel;
                KmTaellerFlyout.Text = bilData.KmTaller;

                PickedCarTextBlock.Text = BilMarkeFlyout.Text + " " + BilModelFlyout.Text;

            }
            catch
            {
                MessageDialog bilLoadFail = new MessageDialog("Kunne ikke hente bildata");
                bilLoadFail.Options = MessageDialogOptions.None;
                bilLoadFail.Commands.Add(new UICommand("Ok"));
                await bilLoadFail.ShowAsync();
            }
        }

        private void RedigerFlyoutButton_Click(object sender, RoutedEventArgs e)
        {
            OpretBilFlyoutButton.Visibility = Visibility.Visible;
            BilMarkeFlyout.IsEnabled = true;
            BilModelFlyout.IsEnabled = true;
            KmTaellerFlyout.IsEnabled = true;
            RedigerFlyoutButton.Visibility = Visibility.Collapsed;
        }











    }
}
