﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.Storage;
using Windows.Storage.Streams;

namespace Diesel.Models
{
    public class Bil
    {
        public string BilMarke { get; set; }
        public string BilModel { get; set; }
        public string KmTaller { get; set; }
    }
}
