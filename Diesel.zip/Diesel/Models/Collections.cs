﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Diesel.Models
{
    public class TankningCollection
    {
        public string Date { get; set; }
        public int KmTaeller { get; set; }
        public double LiterTanket { get; set; }
        public double Pris { get; set; }
        public int KmKoert { get; set; }
        public double PrisPrLiter { get; set; }
        public double KmPrLiter { get; set; }
    }

    public class DiverseCollection
    {
        public string DateDiverse { get; set; }
        public string Beskrivelse { get; set; }
        public double PrisDiverse { get; set; }
    }
}
