﻿using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace Diesel.Models
{
    public class Calculate : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged([CallerMemberName]string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        private string _totalLiterTanket;
        public string TotalLiterTanket
        {
            get { return _totalLiterTanket; }
            set { _totalLiterTanket = value; OnPropertyChanged(); }
        }

        private string _totalPris;
        public string TotalPris
        {
            get { return _totalPris; }
            set { _totalPris = value; OnPropertyChanged(); }
        }

        private string _totalKmKoert;
        public string TotalKmKoert
        {
            get { return _totalKmKoert; }
            set { _totalKmKoert = value; OnPropertyChanged(); }
        }

        private string _gennemsnitPrisPrLiter;
        public string GennemsnitPrisPrLiter
        {
            get { return _gennemsnitPrisPrLiter; }
            set { _gennemsnitPrisPrLiter = value; OnPropertyChanged(); }
        }

        private string _gennemsnitKoertPrLiter;
        public string GennemsnitKoertPrLiter
        {
            get { return _gennemsnitKoertPrLiter; }
            set { _gennemsnitKoertPrLiter = value; OnPropertyChanged(); }
        }

        private string _totalPrisDiverse;
        public string TotalPrisDiverse
        {
            get { return _totalPrisDiverse; }
            set { _totalPrisDiverse = value; OnPropertyChanged(); }
        }
    }
}
