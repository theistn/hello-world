﻿using System;
using Diesel.Models;
using System.Linq;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.Storage;
using Windows.UI.Popups;
using Newtonsoft.Json;
using System.Collections.ObjectModel;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace Diesel.Pages
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class DiversePage : Page
    {

        ObservableCollection<DiverseCollection> diverseCollection;
        public string filenameDiverse = "Diverse.txt";
        public Calculate calculate = new Calculate();

        public DiversePage()
        {
            this.InitializeComponent();
            diverseCollection = new ObservableCollection<DiverseCollection>();
            DatoDiverse.SelectedDate = DateTime.Today;

        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            Load_Diverse();
        }

        private void GodkendDiverse_Click(object sender, RoutedEventArgs e)
        {
            try
            {
               diverseCollection.Add(new DiverseCollection
                {
                    DateDiverse = DatoDiverse.Date.ToString("dd-MM-yyy"),
                    Beskrivelse = BeskrivelseDiverse.Text,
                    PrisDiverse = Convert.ToDouble(PrisDiverse.Text)
                });

                DatoDiverse.SelectedDate = DateTime.Today;
                BeskrivelseDiverse.Text = "";
                PrisDiverse.Text = "";
            }
            catch
            { }

            SaveDiverse();
            Calculate();
        }


        private async void SaveDiverse()
        {
            StorageFolder storageFolder = ApplicationData.Current.LocalFolder;
            StorageFile diverseFile = await storageFolder.CreateFileAsync(filenameDiverse, CreationCollisionOption.OpenIfExists);
            var serializedDiverseList = JsonConvert.SerializeObject(diverseCollection);
            await FileIO.WriteTextAsync(diverseFile, serializedDiverseList);
        }

        private async void Load_Diverse()
        {
            try
            {
                StorageFolder storageFolder = ApplicationData.Current.LocalFolder;
                StorageFile diverseFile = await storageFolder.CreateFileAsync(filenameDiverse, CreationCollisionOption.OpenIfExists);
                string serializedDiverseList = await FileIO.ReadTextAsync(diverseFile);

                if (serializedDiverseList != null)
                {
                    diverseCollection = JsonConvert.DeserializeObject<ObservableCollection<DiverseCollection>>(serializedDiverseList);
                    diverseTable.ItemsSource = diverseCollection;
                }
            }
            catch { }

            Calculate();
        }

        private async void ClearListDiverse_Click(object sender, RoutedEventArgs e)
        {
            MessageDialog dialog = new MessageDialog("Er du sikker på du vil slette listen?", "Slet listen");
            dialog.Commands.Add(new UICommand("Yes", null));
            dialog.Commands.Add(new UICommand("No", null));
            dialog.DefaultCommandIndex = 0;
            dialog.CancelCommandIndex = 1;
            var cmd = await dialog.ShowAsync();

            if (cmd.Label == "Yes")
            {
                diverseCollection.Clear();

                SaveDiverse();
                Calculate();
            }
        }


        private void Calculate()
        {
            try
            {
                double totalPrisDiverse = diverseCollection.Sum(i => i.PrisDiverse);


                if (totalPrisDiverse > 1)
                {
                    calculate.TotalPrisDiverse = totalPrisDiverse.ToString() + " Kr";
                }
                else
                {
                    calculate.TotalPrisDiverse = "";
                }
            }
            catch { }
        }


    }
}
