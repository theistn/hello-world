﻿using System;
using Diesel.Models;
using System.Linq;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.Storage;
using Windows.UI.Popups;
using Newtonsoft.Json;
using System.Collections.ObjectModel;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace Diesel.Pages
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class TankningsPage : Page
    {

        private ObservableCollection<TankningCollection> tankningCollection;
        public Calculate calculate = new Calculate();
        public string filenameBil = "Bil.txt";
        public string filenameTank = "Tankninger.txt";


        public TankningsPage()
        {
            this.InitializeComponent();
            Dato.SelectedDate = DateTime.Today;
            tankningCollection = new ObservableCollection<TankningCollection>();
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            Load_Tankninger();

        }

        private void Godkend_Click(object sender, RoutedEventArgs e)
        {

            if (tankningCollection.Count != 0)
            {
                try
                {
                    tankningCollection.Add(new TankningCollection
                    {
                        Date = Dato.Date.ToString("dd-MM-yyyy"),
                        KmTaeller = Convert.ToInt32(KmTaeller.Text),
                        LiterTanket = Math.Round(Convert.ToDouble(LiterTanket.Text), 2),
                        Pris = Math.Round(Convert.ToDouble(Pris.Text), 2),
                        KmKoert = (Convert.ToInt32(KmTaeller.Text) - Convert.ToInt32(tankningCollection.LastOrDefault().KmTaeller)),
                        PrisPrLiter = Math.Round(Convert.ToDouble(Pris.Text) / Convert.ToDouble(LiterTanket.Text), 2),
                        KmPrLiter = Math.Round((Convert.ToInt32(KmTaeller.Text) - Convert.ToInt32(tankningCollection.LastOrDefault().KmTaeller)) / Convert.ToDouble(LiterTanket.Text), 2)
                    });

                    Dato.SelectedDate = DateTime.Today;
                    KmTaeller.Text = "";
                    Pris.Text = "";
                    LiterTanket.Text = "";
                }
                catch { }
            }
            else
            {
                FoesteTankning();
            }

            SaveTankninger();
            _Calculate();
        }

        private void FoesteTankning()
        {
            try
            {
                var KmTaellerFlyout = MainPage.mainPage.KmTaellerFlyout.Text;

                tankningCollection.Add(new TankningCollection
                {
                    Date = Dato.Date.ToString("dd-MM-yyyy"),
                    KmTaeller = Convert.ToInt32(KmTaeller.Text),
                    LiterTanket = Math.Round(Convert.ToDouble(LiterTanket.Text), 2),
                    Pris = Math.Round(Convert.ToDouble(Pris.Text), 2),
                    KmKoert = (Convert.ToInt32(KmTaeller.Text) - Convert.ToInt32(KmTaellerFlyout)),
                    PrisPrLiter = Math.Round(Convert.ToDouble(Pris.Text) / Convert.ToDouble(LiterTanket.Text), 2),
                    KmPrLiter = Math.Round((Convert.ToDouble(KmTaeller.Text) - (Convert.ToDouble(KmTaellerFlyout))) / Convert.ToDouble(LiterTanket.Text), 2)
                });

                Dato.SelectedDate = DateTime.Today;
                KmTaeller.Text = "";
                Pris.Text = "";
                LiterTanket.Text = "";
            }
            catch { }
        }

        private async void SaveTankninger()
        {
            StorageFolder storageFolder = ApplicationData.Current.LocalFolder;
            StorageFile tankningerFile = await storageFolder.CreateFileAsync(filenameTank, CreationCollisionOption.OpenIfExists);
            var serializedTankningsList = JsonConvert.SerializeObject(tankningCollection);
            await FileIO.WriteTextAsync(tankningerFile, serializedTankningsList);
        }

        private async void Load_Tankninger()
        {
            try
            {
                StorageFolder storageFolder = ApplicationData.Current.LocalFolder;
                StorageFile tankningerFile = await storageFolder.CreateFileAsync(filenameTank, CreationCollisionOption.OpenIfExists);
                string serializedTankningsList = await FileIO.ReadTextAsync(tankningerFile);

                if (serializedTankningsList != null)
                {
                    tankningCollection = JsonConvert.DeserializeObject<ObservableCollection<TankningCollection>>(serializedTankningsList);
                    tankningTable.ItemsSource = tankningCollection;
                }
            }
            catch { }

            _Calculate();
        }

        private async void ClearList_Click(object sender, RoutedEventArgs e)
        {

            MessageDialog dialog = new MessageDialog("Er du sikker på du vil slette listen?", "Slet listen");
            dialog.Commands.Add(new UICommand("Yes", null));
            dialog.Commands.Add(new UICommand("No", null));
            dialog.DefaultCommandIndex = 0;
            dialog.CancelCommandIndex = 1;
            var cmd = await dialog.ShowAsync();

            if (cmd.Label == "Yes")
            {
                tankningCollection.Clear();

                SaveTankninger();
                _Calculate();
            }
        }


        private void _Calculate()
        {
            try
            {
                double totalLiter = tankningCollection.Sum(i => i.LiterTanket);
                double totalPris = tankningCollection.Sum(i => i.Pris);
                double totalKm = tankningCollection.Sum(i => i.KmKoert);
                double gennemsnitPrisPrLiter = Math.Round(tankningCollection.Sum(i => i.PrisPrLiter) / tankningCollection.Count(), 2);
                double gennemsnitKoertPrLiter = Math.Round(tankningCollection.Sum(i => i.KmPrLiter) / tankningCollection.Count(), 2);


                if (totalKm > 1)
                {
                    calculate.TotalLiterTanket = totalLiter.ToString() + " Liter";
                    calculate.TotalPris = totalPris.ToString() + " Kr";
                    calculate.TotalKmKoert = totalKm.ToString() + " Km";
                    calculate.GennemsnitPrisPrLiter = gennemsnitPrisPrLiter.ToString() + " Kr/l";
                    calculate.GennemsnitKoertPrLiter = gennemsnitKoertPrLiter.ToString() + " Km/l";
                }
                else
                {
                    calculate.TotalLiterTanket = "";
                    calculate.TotalPris = "";
                    calculate.TotalKmKoert = "";
                    calculate.GennemsnitPrisPrLiter = "";
                    calculate.GennemsnitKoertPrLiter = "";
                }
            }
            catch { }
        }









    }
}
